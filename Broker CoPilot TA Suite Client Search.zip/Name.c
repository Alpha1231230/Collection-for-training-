Name()
{
	
	lr_save_string(lr_get_attrib_string("token"), "token");
	
	web_add_header("Accept","application/vnd.aonbrokercopilot.api.search.clientenvelope.v1+json");
	
	web_add_header("Grids-Authorization","{token}");
	
	web_add_header("Content-Type","application/json");
	
	web_add_header("Connection","keep-alive");
	
	web_add_header("Accept-Encoding","gzip, deflate, br");
	
	web_add_header("Accept","application/vnd.aonbrokercopilot.api.search.clientenvelope.v1+json");
	
	lr_start_transaction("Search_Name");
	
	web_rest("SearchClients",
    "URL=https://staging.api.aon.com/grids/qa/aonbrokercoilot/search/clients?subscription-key=321cf5664c3d4d8d873d5e767e68534c&Search={p_name}&pagesize=10&page=2&Fields=StreetAddress ",
    "Method=GET",
    "Resource=0",
    "RecContentType=application/json",
    "Referer=",
    "Snapshot=t1.inf",
    "Mode=HTTP",
    LAST);
	
	lr_end_transaction("Search_Name",LR_AUTO);
	
	return 0;
}
